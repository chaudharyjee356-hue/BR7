import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:ffmpeg_kit_flutter/ffmpeg_kit.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const BR7App());

class BR7App extends StatelessWidget {
  const BR7App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'BR7',
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, colorSchemeSeed: Colors.deepPurple),
    home: const MergeScreen(),
  );
}

class MergeScreen extends StatefulWidget {
  const MergeScreen({super.key});
  @override State<MergeScreen> createState() => _MergeScreenState();
}

class _MergeScreenState extends State<MergeScreen> {
  String? video, audio, photo, output;
  String status = 'Select media to begin';
  bool busy = false;
  VideoPlayerController? player;

  Future<void> pick(FileType type, void Function(String) save) async {
    final r = await FilePicker.platform.pickFiles(type: type);
    final p = r?.files.single.path;
    if (p != null) setState(() { save(p); status = 'File selected'; });
  }

  Future<String> out(String name) async {
    final d = await getApplicationDocumentsDirectory();
    return '${d.path}/${name}_${DateTime.now().millisecondsSinceEpoch}.mp4';
  }

  Future<void> run(String cmd, String path) async {
    setState(() { busy = true; output = null; status = 'Processing…'; player?.dispose(); player = null; });
    try {
      final s = await FFmpegKit.execute(cmd);
      final rc = await s.getReturnCode();
      if (File(path).existsSync() && File(path).lengthSync() > 0) {
        final p = VideoPlayerController.file(File(path));
        await p.initialize();
        await p.setLooping(true);
        if (!mounted) { await p.dispose(); return; }
        setState(() { player = p; output = path; status = 'Ready'; });
      } else {
        snack('Processing failed. FFmpeg code: $rc');
        setState(() => status = 'Failed');
      }
    } catch (e) {
      snack('Error: $e');
      setState(() => status = 'Failed');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> mergeVideoAudio() async {
    if (video == null || audio == null) return snack('पहले Video और Audio चुनें');
    final o = await out('BR7_video_audio');
    await run('-y -i "$video" -i "$audio" -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -shortest "$o"', o);
  }

  Future<void> photoVideo() async {
    if (photo == null || audio == null) return snack('पहले Photo और Audio चुनें');
    final o = await out('BR7_photo_video');
    await run('-y -loop 1 -i "$photo" -i "$audio" -map 0:v:0 -map 1:a:0 -vf "scale=3840:2160:force_original_aspect_ratio=decrease,pad=3840:2160:(ow-iw)/2:(oh-ih)/2" -r 30 -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -shortest "$o"', o);
  }

  void snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Widget card(IconData icon, String title, String hint, String? value, VoidCallback tap) =>
    Card(child: ListTile(
      leading: CircleAvatar(child: Icon(icon)),
      title: Text(title),
      subtitle: Text(value == null ? hint : value.split('/').last),
      trailing: const Icon(Icons.folder_open),
      onTap: busy ? null : tap,
    ));

  @override
  Widget build(BuildContext context) {
    final p = player;
    return Scaffold(
      appBar: AppBar(title: const Text('BR7 Media'), centerTitle: true),
      body: SafeArea(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          card(Icons.video_library, 'Select Video', '4K video supported', video, () => pick(FileType.video, (x) => video = x)),
          card(Icons.music_note, 'Select Audio', 'Music / TTS / voice', audio, () => pick(FileType.audio, (x) => audio = x)),
          card(Icons.photo, 'Select Photo', 'Turn photo into video', photo, () => pick(FileType.image, (x) => photo = x)),
          const SizedBox(height: 6),
          Text(status),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: busy ? null : mergeVideoAudio, icon: const Icon(Icons.merge_type), label: const Text('Video + Audio'))),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(onPressed: busy ? null : photoVideo, icon: const Icon(Icons.movie_creation), label: const Text('Photo + Audio'))),
          ]),
          const SizedBox(height: 12),
          Expanded(child: busy
            ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [CircularProgressIndicator(), SizedBox(height: 12), Text('BR7 is creating your video…')]))
            : output == null
              ? const Center(child: Text('Your finished video will appear here'))
              : p != null && p.value.isInitialized
                ? Center(child: AspectRatio(aspectRatio: p.value.aspectRatio, child: VideoPlayer(p)))
                : const Center(child: CircularProgressIndicator())),
          if (output != null) Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () { if (player == null) return; setState(() { player!.value.isPlaying ? player!.pause() : player!.play(); }); },
              icon: const Icon(Icons.play_arrow), label: const Text('Play / Pause'))),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(
              onPressed: () => Share.shareXFiles([XFile(output!)]),
              icon: const Icon(Icons.share), label: const Text('Save / Share'))),
          ]),
        ]),
      )),
    );
  }

  @override
  void dispose() { player?.dispose(); super.dispose(); }
}
