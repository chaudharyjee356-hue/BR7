# BR7 Flutter Project

Features:
- Pick video, audio and photos directly from Android.
- Merge video + audio.
- Convert a photo into a 3840x2160 (4K canvas) video with audio.
- Preview, play/pause and share the MP4.
- 4K input video is accepted; video+audio mode copies the video stream.

Build:
```bash
flutter pub get
flutter build apk --release
```
APK:
`build/app/outputs/flutter-apk/app-release.apk`

Note: `ffmpeg_kit_flutter` is an older FFmpegKit package. If your current Flutter/Android setup cannot resolve it, use a maintained compatible FFmpegKit fork and update the import/dependency.
